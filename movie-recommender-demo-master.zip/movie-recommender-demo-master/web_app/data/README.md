The movies.dat and ratings.dat datasets are generated with generate_movie_data.py

The license for these datasets is here: https://github.com/snowch/movie-recommender-demo/blob/master/licenses.md
