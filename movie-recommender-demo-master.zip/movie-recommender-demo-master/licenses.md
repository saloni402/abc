- The [movies.dat](./web_app/data/movies.dat) data is under the license [CC-BY-SA-3.0](https://creativecommons.org/licenses/by-sa/3.0/). The movie names and movie urls in movies.dat were obtained from the following sources:
  
  - https://en.wikipedia.org/wiki/2007_in_film
  - https://en.wikipedia.org/wiki/2008_in_film
  - https://en.wikipedia.org/wiki/2009_in_film
  - https://en.wikipedia.org/wiki/2010_in_film
  - https://en.wikipedia.org/wiki/2011_in_film
  - https://en.wikipedia.org/wiki/2012_in_film
  - https://en.wikipedia.org/wiki/2013_in_film
  - https://en.wikipedia.org/wiki/2014_in_film
  - https://en.wikipedia.org/wiki/2015_in_film
  - https://en.wikipedia.org/wiki/2016_in_film
  - https://en.wikipedia.org/wiki/2017_in_film
 
- The rest of this project is under the license [APACHE 2.0](https://www.apache.org/licenses/LICENSE-2.0.html)
